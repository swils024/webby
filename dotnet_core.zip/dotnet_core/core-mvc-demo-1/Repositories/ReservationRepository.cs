using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace core_mvc_demo_1.Respositories
{
    class ReservationRepository
    {
        HttpClient client = new HttpClient();

        public ReservationRepository()
        {
            client.BaseAddress = new Uri("http://localhost:57772");
            client.DefaultRequestHeaders.Accept.Add(
                new MediaTypeWithQualityHeaderValue("application/json"));
            
        }

        public async Task<HttpResponseMessage> GetAsync(CancellationToken cancellationToken)
        {
            await Task.Delay(3000);

            cancellationToken.ThrowIfCancellationRequested();

            HttpResponseMessage response = await client.GetAsync("rnr/travel/reservations", cancellationToken);
            
            if (response.IsSuccessStatusCode)
            {
                var stringResult = await response.Content.ReadAsStringAsync();
                return JsonConvert.DeserializeObject<HttpResponseMessage>(stringResult);
            } 

            else
            {
                var stringResult = await response.Content.ReadAsStringAsync();
                return JsonConvert.DeserializeObject<HttpResponseMessage>(stringResult);
            }           
        }

        public async Task<HttpResponseMessage> GetData()
        {

            await Task.Delay(3000);

            HttpResponseMessage response = await client.GetAsync("rnr/travel/reservations");

            if (response.IsSuccessStatusCode)
            {
                return response;
            }

            else
            {
                return response;
            }

        }


    }
}