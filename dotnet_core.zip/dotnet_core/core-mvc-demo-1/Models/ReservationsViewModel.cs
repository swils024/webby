using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading;
using System.Threading.Tasks;
using core_mvc_demo_1.Respositories;


namespace core_mvc_demo_1.Models
{
    public class ReservationsViewModel
    {
        public string RequestId { get; set; }

        public bool ShowRequestId => !string.IsNullOrEmpty(RequestId);

        public string JSONResult = GetAllReservations();

        public string SomeValue = "Here is some value";

        private static CancellationTokenSource tokenSource;


        public static String GetAllReservations()
        {
            String reservations = "Set inside ReservationsViewModel.GetAllReservations()";
            tokenSource = new CancellationTokenSource();

            var repository = new ReservationRepository();
            
            //Task<String> reservationTask = repository.GetAsync(tokenSource.Token);
            Task<HttpResponseMessage> reservationTask = repository.GetAsync(tokenSource.Token);
            

            reservationTask.ContinueWith(task => 
            {
                reservations = task.Result.ToString();
            },
            TaskContinuationOptions.OnlyOnRanToCompletion);

            reservationTask.ContinueWith(
                HandleError,
                TaskContinuationOptions.OnlyOnFaulted);

            return reservations;
        }

        private static String HandleError(Task<HttpResponseMessage> task)
        {
            return "There was a problem retrieving data";
        }
    }
}